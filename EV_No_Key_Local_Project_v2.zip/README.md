# E.V. — No-Key Local Brain v2

This version fixes the mobile/iPhone layout and uses an ONNX-compatible
Qwen2.5-0.5B-Instruct model through Transformers.js.

- No OpenAI API key
- No Gemini API key
- No backend
- Existing E.V. browser storage is preserved (`ev-history`, `ev-memory`,
  `ev-agenda`, voice settings)
- Mobile layout uses the device viewport (`100dvh`) and safe-area padding
- The local model is downloaded and cached by the browser on first use

The first AI response can take a while while the model downloads. If the
browser preview blocks external model downloads, deploy the page to normal
static hosting and open the deployed HTTPS URL.
